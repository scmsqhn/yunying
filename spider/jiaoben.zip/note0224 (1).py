笔记

1 安装redis在笔w和单u ok
2 部署scrapy-redis
  1 importerror： can not import 问题
3 完成抓取