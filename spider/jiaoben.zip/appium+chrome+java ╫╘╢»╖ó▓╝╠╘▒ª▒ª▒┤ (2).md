# appium+chrome+java 自动发布淘宝宝贝

## 如何使用chrome在appium平台
> chrome 与 chromedriver版本有对应关系
使用nuget 管理驱动库
java正则表达式，取数字
