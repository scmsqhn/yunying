完成链家数据采集分析

1 SCRAPY爬虫
  1 可以下载部分数据
	2 环境配置繁琐#
	3 数据下载不全
	3 scrapy知识不足#
  4 将数据导入MySQLdb #0218
    1 python2编码格式，不清楚
    2 直接写入数据库，方式不清楚
    3 多看python tutorial
    4 多想少动，想清楚了，再动
    5 准备好数据，一次性写入数据库
	  1 cmd /k python "$(G:\ProgramData\Anaconda2\usr\sqlitetool.py)" & PAUSE & EXIT 
		在notepad环境运行python
    6 将成都市低保数据，在百度地图获得经纬度 OK
      1 经纬度不准确 ok #0219
    7 将低保经纬度，在地图上进行描点 ING
      初步选定https://me.bdp.cn/register.html 个人bdp网上工具制作 ok
    8 
2 地图描点
	1 如何描点 
    1 python加 linux 还是 android加java #
	2 具体实现demo代码学习
  

3 数据分析归类
	1 模型训练环境搭建
	2 模型训练
	3 输出修正模型
